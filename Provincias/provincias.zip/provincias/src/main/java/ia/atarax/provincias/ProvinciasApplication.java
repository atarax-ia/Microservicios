package ia.atarax.provincias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProvinciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvinciasApplication.class, args);
	}

}
