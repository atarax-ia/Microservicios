package ia.atarax.provincias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvinciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
