package ia.atarax.localidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalidadesApplication.class, args);
	}

}
