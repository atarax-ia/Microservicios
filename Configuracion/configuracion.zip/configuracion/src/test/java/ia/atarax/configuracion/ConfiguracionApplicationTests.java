package ia.atarax.configuracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfiguracionApplicationTests {

	@Test
	void contextLoads() {
	}

}
